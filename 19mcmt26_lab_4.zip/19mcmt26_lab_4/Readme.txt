Files:
	knapsack.c contains program of 0/1 knapsack problem using Dynaic programming approach.
	knap_inp.txt contains input
		first line : weight of knapsack
		second line : total items
		next three line contain profit
		next three line contain weight of items
	knap_out.txt contains output of the program:
		first line :: total profit
		second line :: output vector
		third line :: index of items selected
		
commands:
	>g++ knapsack.c
	>./a.out kanp_inp.txt knap_out.txt
