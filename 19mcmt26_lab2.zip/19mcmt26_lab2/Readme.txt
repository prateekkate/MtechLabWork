There are three program files:
1.random_Numbers.c [to generate random numbers in a file]
    *Command to run this file:

        >gcc random_Numbers.c 
        >./a.out #numbers filename.txt 

        #number::How many numbers you want to generate 
        filename.txt in which file these no you want to write

2.bubble_sort.c
    *Command to run this file:
        
        >gcc bubble_sort.c
        >./a.out input_file.txt output_file.txt

        input.txt contains the name of input file
        output.txt is output file in which sorted file is stored.
all commands:
>gcc random_Numbers.c
>./a.out 1000 random_1000.txt

  Similarly for other 9 files.(change 1000 to 2000 and so on till 10000)  

>sort random_1000.txt > asc_1000.txt

  Similarly for other 9 files.(change 1000 to 2000 and so on till 10000)

>sort -r random_1000.txt > dsc_1000.txt

  Similarly for other 9 files.(change 1000 to 2000 and so on till 10000)

>gcc bubble_sort.c
>./a.out random_1000.txt rout1000.txt

  Similarly for other 9 files.(change 1000 to 2000 and so on till 10000)  

>./a.out asc_1000.txt out.txt

  Similarly for other 9 files.(change 1000 to 2000 and so on till 10000)


>./a.out dsc_1000.txt odsc.txt

   Similarly for other 9 files.(change 1000 to 2000 and so on till 10000)


3. insertion_sort.c

   All the work we have done for bubble sort we have to done again for insertion sort also.


4. For graph plotting please see graph.py and for graphs please see Bubble_sort.png and Insertion_Sort.png


